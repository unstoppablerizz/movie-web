# Security Policy

## Supported Versions

The latest version of movie-web is the only version that is supported, as it is the only version that is being actively developed.

## Reporting a Vulnerability

You can contact the movie-web maintainers to report a vulnerability:
 - Report the vulnerability in the [movie-web Discord server](https://movie-web.github.io/links/discord)
